module.exports = {
  secret: 'worldisfullofdevelopers'
};
